import sys
import time
import random
import math

class Program():
  __interpretation_started_timestamp__ = time.time() * 1000

  pi = 3.141592653589793

  def execMain(self):
    Diam = 0.056 #диаметр колес робота, в метрах
    L = 0.077 #полуколея робота, в метрах
    
    N = 3     # количество перекрестков
    total = 0 # счетчик количества перекрестков    

    VL = 0 # скорость левого колеса
    VR = 0 # скорость правого колеса
    
    # переменные для ПИД регулятора
    kp = 1.5 
    ki = 0 
    kd = 0 
    err = 0 
    errold = 0 
    I = 0 
 
    s1, s4 = 0, 0 # переменные для данных с сенсоров
    while total < N: 
      while (s1 + s4) < 50: 
        s1 = brick.sensor("A1").read() 
        s2 = brick.sensor("A2").read() 
        s3 = brick.sensor("A3").read() 
        s4 = brick.sensor("A4").read() 

        err = s2 - s3
        
        P = kp * err 
        I = I + ki * err 
        D = kd * (err - errold) 
        U = P + I + D 
        VL = 50 - U
        VR = 50 + U
        errold = err
        
        brick.motor("M3").setPower(VR) 
        brick.motor("M4").setPower(VL)
        script.wait(10) 
      
      total = total + 1
      brick.playTone(200, 300)
      
      startTime = script.time() 
      dt = 0 
      while dt < 800: 
        s1 = brick.sensor("A1").read() 
        s2 = brick.sensor("A2").read() 
        s3 = brick.sensor("A3").read() 
        s4 = brick.sensor("A4").read() 
        err = s2 - s3 
        P = kp * err 
        I = I + ki * err 
        D = kd * (err - errold) 
        U = P + I + D 
        VL = 50 - U 
        VR = 50 + U 
        errold = err
        
        brick.motor("M3").setPower(VR) 
        brick.motor("M4").setPower(VL) 
        script.wait(10) 
        dt = script.time() - startTime
        
    brick.motor("M3").powerOff()
    brick.motor("M4").powerOff()
    script.wait(10)
    brick.stop()
    return

def main():
  program = Program()
  program.execMain()

if __name__ == '__main__':
  main()
