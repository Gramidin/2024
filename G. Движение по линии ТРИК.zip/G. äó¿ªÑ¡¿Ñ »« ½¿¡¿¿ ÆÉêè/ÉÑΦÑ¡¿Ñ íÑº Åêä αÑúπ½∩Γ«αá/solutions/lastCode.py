import sys
import time
import random
import math

class Program():
  __interpretation_started_timestamp__ = time.time() * 1000

  pi = 3.141592653589793

  def execMain(self):
    Diam=0.056 #диаметр колес робота, в метрах
    L=0.077 #полуколея робота, в метрах
    
    #добавьте свой код ниже
    
    
    brick.motor("M3").powerOff()
    brick.motor("M4").powerOff()
    script.wait(10)
    brick.stop()
    return

def main():
  program = Program()
  program.execMain()

if __name__ == '__main__':
  main()
