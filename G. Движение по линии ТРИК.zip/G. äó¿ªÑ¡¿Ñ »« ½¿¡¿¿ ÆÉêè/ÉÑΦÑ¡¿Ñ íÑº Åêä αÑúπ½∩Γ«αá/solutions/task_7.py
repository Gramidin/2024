import sys
import time
import random
import math

class Program():
  __interpretation_started_timestamp__ = time.time() * 1000

  pi = 3.141592653589793

  def execMain(self):
    Diam=0.056 #диаметр колес робота, в метрах
    L=0.077 #полуколея робота, в метрах
    
    def forward():
      brick.motor("M3").setPower(100)
      brick.motor("M4").setPower(100)
      
    def line():
      if brick.sensor('A2').read() > 27 or brick.sensor('A3').read() < 27:
        brick.motor("M3").setPower(100) 
        brick.motor("M4").setPower(1)  
      if brick.sensor('A3').read() > 27 or brick.sensor('A2').read() < 27:
        brick.motor("M3").setPower(1)  
        brick.motor("M4").setPower(100) 
     
    total = 0
    forward()
    script.wait(1500)
    
    while total < 3:
      line()
      if brick.sensor('A1').read() > 27 and brick.sensor('A4').read() > 27:
        total +=1
        while brick.sensor('A1').read() > 27 and brick.sensor('A4').read() > 27:
          forward()
    
    
    brick.motor("M3").powerOff()
    brick.motor("M4").powerOff()
    script.wait(10)
    brick.stop()
    return

def main():
  program = Program()
  program.execMain()

if __name__ == '__main__':
  main()
